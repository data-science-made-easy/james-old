#' Initialize James
#'
#' Creates or opens a file and a JRoot object holding your data
#'
#' @param file_name File holding your archive. Defaults to <username>.james in your home directory, where <username> is your username
#' @param active_scenario Scenario you want to work on
#' @param active_project Project you want to work on
#'
#' @return JRoot object holding your data
#'
#' @examples
#' .j_root <- j_init()
#'
#' @export

j_init <- function(file_name = paste0(Sys.getenv("HOME"), .Platform$file.sep, Sys.info()["user"], ".james"), active_scenario, active_project) {
  JRoot$new(file_name, active_scenario, active_project)
}